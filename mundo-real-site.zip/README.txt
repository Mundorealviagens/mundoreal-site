Projeto Mundo Real Viagens - estrutura base para deploy em Vercel ou hospedagem própria.
