// Página sobre o compromisso com segurança
